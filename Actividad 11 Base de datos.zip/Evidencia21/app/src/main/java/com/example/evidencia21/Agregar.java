package com.example.evidencia21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.evidencia21.db.Plataforma;

public class Agregar extends AppCompatActivity  {
    private EditText et_Nombre;
    private EditText et_Busqueda;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
        et_Nombre=(EditText)findViewById(R.id.txt_Nombre);
        et_Busqueda=(EditText)findViewById(R.id.Buscarplata);
    }
    //metodo para el nombre de la plataforma
    public void Registrar (View view) {
        Plataforma admin    = new Plataforma(this,"Administrador",null,1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
        String Nombre = et_Nombre.getText().toString();
        if (!Nombre.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("Nombre",Nombre);
            BaseDeDatos.insert("Plataforma", null,registro);
            BaseDeDatos.close();
            et_Nombre.setText("");
            Toast.makeText(this,"Registro exitoso",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this,"Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }

    }
    //Metodo para consultar plataforma
    public void Buscar(View view){
        Plataforma admin = new Plataforma(this,"Administrador",null,1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
        String Nombre =et_Nombre.getText().toString();
        if (!Nombre.isEmpty()){
            Cursor fila = BaseDeDatos.rawQuery
                    ("Select Nombre, from Plataforma,"+Nombre,null);
            if(fila.moveToFirst()){
                et_Busqueda.setText(fila.getString(0));
                BaseDeDatos.close();
            }else{
                Toast.makeText(this,"No Existe la plataforma",Toast.LENGTH_SHORT).show();
                BaseDeDatos.close();
            }

        }else{
            Toast.makeText(this,"Introduce el nombre de la plataforma",Toast.LENGTH_SHORT).show();
        }

    }


}