package com.example.evidencia21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Registrarse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
    }

    public void mandaingresar(View view) {
        Intent miIntent;
        miIntent = new Intent(Registrarse.this,Agregar.class);
        startActivity(miIntent);
    }
}