package com.example.actividad4final.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public GalleryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Andrew Russell Garfield es un actor y productor estadounidense. A pesar de haber nacido en Los Ángeles, se crio en Epsom, Surrey, donde comenzó a actuar en teatros y producciones televisivas.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}