package com.example.actividad4final.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Thomas Stanley Holland, conocido simplemente como Tom Holland, es un actor, actor de voz y bailarín británico. Comenzó su carrera en el teatro en 2008 interpretando al personaje principal en el musical Billy Elliot");
    }

    public LiveData<String> getText() {
        return mText;
    }
}