package com.example.actividad4final.ui.slideshow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SlideshowViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public SlideshowViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Tobias Vincent Maguire es un actor y productor de cine estadounidense conocido principalmente por interpretar a Peter Parker en la trilogía de Spider-Man de Sam Raimi y en la vigésimo séptima película del Universo cinematográfico de Marvel, Spider-Man: No Way Home");
    }

    public LiveData<String> getText() {
        return mText;
    }
}