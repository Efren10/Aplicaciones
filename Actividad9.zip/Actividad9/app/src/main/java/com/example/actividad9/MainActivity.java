package com.example.actividad9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
        Handler handler = new Handler() {
            public void handleMessage(Message message) {
                TextView textView = (TextView) findViewById(R.id.textView);
                textView.setText("Message message");
            }
        };

        public void MakeOperation(View view) {
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    long actualTime = System.currentTimeMillis();
                    long finalTime = actualTime + 20000;
                    while (System.currentTimeMillis() < finalTime) {
                        synchronized (this) {
                            try {
                                wait(finalTime - System.currentTimeMillis());
                            } catch (Exception e) {
                            }
                        }
                    }
                    handler.sendEmptyMessage ( 0);
                }
            };
            Thread thread = new Thread (runnable);
            thread.start();
            TextView textView= (TextView) findViewById(R.id.textView);
            textView.setText("Fin");
    }
}