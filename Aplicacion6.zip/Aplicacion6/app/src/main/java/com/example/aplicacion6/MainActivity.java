package com.example.aplicacion6;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{
    private TextView nacio, Añoscumplidos, Fechacon, meses1;
    private EditText dateInput;
    private String Diaselect = "";
    private String Messelect = "";
    private Calendar Dianacim;
    private Calendar Mesnacim;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button)findViewById(R.id.button);
        nacio = (TextView)findViewById(R.id.nacio);
        Añoscumplidos = (TextView)findViewById(R.id.Añoscumplidos);
        meses1 = (TextView)findViewById(R.id.meses1);
        Fechacon = (TextView)findViewById(R.id.Fechacon);
        dateInput = (EditText)findViewById(R.id.dateInput);
        dateInput.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                DialogFragment datePickerDialog = new TimePickerFragment();
                datePickerDialog.show(getSupportFragmentManager(), "date-picker");
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar consultaDate = Calendar.getInstance();
                Fechacon.setText(DateFormat.getDateInstance(DateFormat.FULL).format(consultaDate.getTime()).toString());
                nacio.setText(Diaselect);
                meses1.setText(Messelect);
                Integer meses1int = consultaDate.get(Calendar.DAY_OF_MONTH) - Dianacim.get((Calendar.MONTH));
                meses1.setText(meses1int.toString());
                Integer edadint = consultaDate.get(Calendar.YEAR) - Dianacim.get((Calendar.YEAR));
                Añoscumplidos.setText(edadint.toString());
            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

        Dianacim = Calendar.getInstance();
        Mesnacim = Calendar.getInstance();
        Dianacim.set(Calendar.YEAR,year);
        Dianacim.set(Calendar.MONTH,month);
        Dianacim.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        Mesnacim.set(Calendar.YEAR,year);
        Mesnacim.set(Calendar.MONTH,month);
        Mesnacim.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        Diaselect = DateFormat.getDateInstance(DateFormat.FULL).format(Dianacim.getTime());
        Messelect = DateFormat.getDateInstance(DateFormat.FULL).format(Mesnacim.getTime());
        dateInput.setText(Diaselect);
        dateInput.setText(Messelect);
    }
}