package com.example.evidencia21;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Registrarse extends AppCompatActivity {
    /*private FirebaseAuth mAuth;
    private EditText correo;
    private EditText contrasena;
    private EditText contrasenacomfirmacion;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);
       /* mAuth = FirebaseAuth.getInstance();
        correo = findViewById(R.id.correoregistrarse);
        contrasena = findViewById(R.id.constrasenaregistrarse);
        contrasenacomfirmacion = findViewById(R.id.constrasenacomfirregis);*/
    }

    /*@Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        //updateUI(currentUser);
    }

    public void registrarusuario(View view) {
        if (contrasena.getText().toString().equals(contrasenacomfirmacion.getText().toString())){
            mAuth.createUserWithEmailAndPassword(correo.getText().toString(), contrasena.getText().toString())
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            try {
                                task.isSuccessful();
                                    // Sign in success, update UI with the signed-in user's information
                                    //Log.d(TAG, "createUserWithEmail:success");
                                    Toast.makeText(getApplicationContext(), "in.", Toast.LENGTH_SHORT).show();
                                    //FirebaseUser user = mAuth.getCurrentUser();
                                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(i);//updateUI(user);

                            } catch (Exception e) {
                                    // If sign in fails, display a message to the user.
                                    //Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(getApplicationContext(), "Authentication failed.", Toast.LENGTH_SHORT).show();
                                    //updateUI(null);
                                e.printStackTrace();
                            }

                        }
                    });

            }
        }*/
    }
