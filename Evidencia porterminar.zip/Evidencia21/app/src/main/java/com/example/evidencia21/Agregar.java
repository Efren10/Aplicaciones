package com.example.evidencia21;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.evidencia21.db.Plataforma;

import java.util.Calendar;

public class Agregar extends AppCompatActivity {
    private EditText et_Nombre;
    private EditText et_Busqueda;
    TextView vt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
        vt = findViewById(R.id.textView);
        et_Nombre=(EditText)findViewById(R.id.txt_Nombre);
        et_Busqueda=(EditText)findViewById(R.id.Buscarplata);
    }

    public void abrircalendario(View view) {
        Calendar cal = Calendar.getInstance();
        int anio = cal.get(Calendar.YEAR);
        int mes = cal.get(Calendar.MONTH);
        int dia = cal.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dpd = new DatePickerDialog(Agregar.this, (view1, year, month, dayOfMonth) -> {
            String fecha = dayOfMonth + "/" + month + "/" + year;
            vt.setText(fecha);
        }, dia, mes, anio);
        dpd.show();
    }

    //Metodo para consultar plataforma
    public void Buscar(View view) {
        Plataforma admin = new Plataforma(this, "Administrador", null, 1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
        String Nombre = et_Nombre.getText().toString();
        if (!Nombre.isEmpty()) {
            Cursor fila = BaseDeDatos.rawQuery
                    ("Select Nombre, from Plataforma," + Nombre, null);
            if (fila.moveToFirst()) {
                et_Busqueda.setText(fila.getString(0));
                BaseDeDatos.close();
            } else {
                Toast.makeText(this, "No Existe la plataforma", Toast.LENGTH_SHORT).show();
                BaseDeDatos.close();
            }

        } else {
            Toast.makeText(this, "Introduce el nombre de la plataforma", Toast.LENGTH_SHORT).show();
        }

    }

    //metodo para el nombre de la plataforma
    public void Registrar(View view) {
        Plataforma admin = new Plataforma(this, "Administrador", null, 1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
        String Nombre = et_Nombre.getText().toString();
        if (!Nombre.isEmpty()) {
            ContentValues registro = new ContentValues();
            registro.put("Nombre", Nombre);
            BaseDeDatos.insert("Plataforma", null, registro);
            BaseDeDatos.close();
            et_Nombre.setText("");
            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}


