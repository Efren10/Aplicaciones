package com.example.evidencia21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Ingresar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingresar2);
    }
}