package com.example.evidencia21;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageButton imagen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imagen = findViewById(R.id.imageButton);
    }


    public void Ingresar(View view) {
        Intent miIntent;
        miIntent = new Intent(MainActivity.this,Ingresar.class);
        startActivity(miIntent);
    }

    public void registrarse(View view) {
        Intent miIntent;
        miIntent = new Intent(MainActivity.this,Registrarse.class);
        startActivity(miIntent);
    }

    @SuppressLint("IntentReset")
    public void Imagendeperfil(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType ("image/");
        startActivityForResult(Intent.createChooser(intent, "Seleccione la Aplicación"), 10);
    }
    @Override
    protected void onActivityResult (int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri path = data.getData();
            imagen.setImageURI(path);
        }
    }
}