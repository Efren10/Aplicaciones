package com.example.evidencia21.db;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.evidencia21.Agregar;

public class Plataforma extends SQLiteOpenHelper {


    public Plataforma(@Nullable Context context, String name, SQLiteDatabase. CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase BaseDeDatos) {
        BaseDeDatos.execSQL("Create table Plataforma(Nombre text,Busqueda text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
