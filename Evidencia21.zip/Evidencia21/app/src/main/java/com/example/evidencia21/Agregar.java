package com.example.evidencia21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Agregar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
    }

    public void mandaagregar(View view) {
        Intent miIntent;
        miIntent = new Intent(Agregar.this,Seleccionar.class);
        startActivity(miIntent);
    }
}