package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Pag1(View v){
        Intent i = new Intent(this, producto1.class);
        switch (v.getId()){
            case R.id.button:
                i.putExtra("url",getResources().getString(R.string.Audifonos));
                break;
            case R.id.button2:
                i.putExtra("url",getResources().getString(R.string.Teclado));
                break;
            case R.id.button3:
                i.putExtra("url",getResources().getString(R.string.Mouse));
                break;
            case R.id.button4:
                i.putExtra("url",getResources().getString(R.string.Monitor));
                break;
            case R.id.button6:
                i.putExtra("url",getResources().getString(R.string.Escritorio));
                break;
        }
        startActivity(i);
    }
}