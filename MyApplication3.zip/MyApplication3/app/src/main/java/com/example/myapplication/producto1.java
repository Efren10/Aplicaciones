package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

public class producto1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_producto1);
        String url = getIntent().getStringExtra("url");
        WebView pagina1 = (WebView) findViewById(R.id.pagina1);
        pagina1.loadUrl(url);
    }
    public void Regresar(View v){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
    }
}