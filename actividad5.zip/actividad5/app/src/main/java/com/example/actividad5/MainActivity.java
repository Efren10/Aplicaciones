package com.example.actividad5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Switch swi1, swi2, swi3, swi4, swi5;
    private boolean articulo1, articulo2, articulo3, articulo4, articulo5 = false;
    private ArrayList<String> articles = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        swi1 = (findViewById(R.id.switch1));
        swi2 = (findViewById(R.id.switch2));
        swi3 = (findViewById(R.id.switch3));
        swi4 = (findViewById(R.id.switch4));
        swi5 = (findViewById(R.id.switch5));
        textView =findViewById(R.id.textView);

        swi1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(articulo1){
                    articulo1 = false;
                }else{
                    articulo1 = true;
                }
            }
        });
        swi2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(articulo2){
                    articulo2 = false;
                }else{
                    articulo2 = true;
                }
            }
        });
        swi3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(articulo3){
                    articulo3 = false;
                }else{
                    articulo3 = true;
                }
            }
        });
        swi4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(articulo4){
                    articulo4 = false;
                }else{
                    articulo4 = true;
                }
            }
        });
        swi5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(articulo5){
                    articulo5 = false;
                }else{
                    articulo5 = true;
                }
            }
        });
    }
    public void Incrementa(View view){
        textView.setText("");
        if(articulo1){
            textView.setText(textView.getText().toString() + ", " + swi1.getText().toString());
        }
        if(articulo2){
            textView.setText(textView.getText().toString() + ", " +swi2.getText().toString());
        }
        if(articulo3){
            textView.setText(textView.getText().toString() + ", "+ swi3.getText().toString());
        }
        if(articulo4){
            textView.setText(textView.getText().toString() + ", " + swi4.getText().toString());
        }
        if(articulo5){
            textView.setText(textView.getText().toString()+ ", " + swi5.getText().toString());
        }

    }
}